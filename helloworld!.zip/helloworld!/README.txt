1. Inside the .venv virtual environment create a new project. 

2. Some .py files presents in the directory

3. Run the command python manage.py runserver. An URL is obtained.

4. Ruen the URL in web browser. Django install worked successfully. 

5. Create new app by using command startapp

6. Updates the lines in the different files present inside the both new project and app

7. Again restart the server by giving the command of python manage.py runserver. An URL is obtained. 

8. Visit the URL in web browser.

9. A message of Hello World! is obtained successfully. 